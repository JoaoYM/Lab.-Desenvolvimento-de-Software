package main.java.universidade.curso;

public interface Credito {
    int getCargaHoraria();
}