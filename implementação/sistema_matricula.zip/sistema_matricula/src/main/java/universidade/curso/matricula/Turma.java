package main.java.universidade.curso.matricula;

import main.java.universidade.users.Professor;

public class Turma {
    private int ano;
    private int semestre;
    private Disciplina disciplina;
    private Professor professor;
}