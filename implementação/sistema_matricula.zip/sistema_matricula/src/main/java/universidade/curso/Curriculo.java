package main.java.universidade.curso;

import java.util.List;

public class Curriculo {
    private List<Curso> cursos;
}