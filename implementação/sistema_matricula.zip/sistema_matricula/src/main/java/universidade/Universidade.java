package main.java.universidade;

import java.util.List;

import main.java.universidade.curso.Curriculo;

public class Universidade {
    private List<Curriculo> curriculos;
}